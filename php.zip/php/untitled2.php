<?php
if (isset($_POST["submit"])) {
    if (isset($_POST["fname"]) && isset($_POST["firname"]) && isset($_POST["lname"]) && isset($_POST["role"]) && isset($_POST["date"]) && isset($_POST["uploadfile"]) && isset($_POST["Gender"])  && isset($_POST["address"]) && isset($_POST["emename"]) && isset($_POST["ememobno"]) && isset($_POST["comment"])) {
        $fname = $_POST["fname"];
        $firname = $_POST["firname"];
        $lname = $_POST["lname"];
        $date = $_POST["date"];
        $role = $_POST["role"];
        $Gender = $_POST["Gender"];
        $address = $_POST["address"];
        $emename = $_POST["emename"];
        $mobno = $_POST["mobno"];
        $ememobno = $_POST["ememobno"];
        $comment = $_POST["comment"];
    }
}

// database details
$host = "localhost";
$username = "root";
$password = "";
$dbname = "sampledb";

// creating a connection
$con = mysqli_connect($host, $username, $password, $dbname);

// to ensure that the connection is made
if (!$con) {
    die("Connection failed!" . mysqli_connect_error());
}

// using sql to create a data entry query
$sql = "INSERT INTO sample(fname,  firname,   lname, date , role,Gender,address, emename, mobno ,ememobno,comment) VALUES ('$fname','$firname',' $lname','$date',   '$role',  '$Gender','$address','$emename', '$mobno','$ememobno', '$comment')";
// send query to the database to add values and confirm if successful
$rs = mysqli_query($con, $sql);
if ($rs) {
    echo "Entries added!";
}

// close connection
mysqli_close($con);
?>