-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 18, 2023 at 02:45 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sampledb`
--

-- --------------------------------------------------------

--
-- Table structure for table `sample`
--

CREATE TABLE `sample` (
  `fname` varchar(25) NOT NULL,
  `firname` varchar(10) NOT NULL,
  `lname` varchar(10) NOT NULL,
  `date` datetime(6) NOT NULL,
  `role` varchar(20) NOT NULL,
  `male` enum('Male','femlae') NOT NULL,
  `Gender` enum('Female') NOT NULL,
  `address` varchar(50) NOT NULL,
  `emename` varchar(25) NOT NULL,
  `mobno` bigint(10) NOT NULL,
  `ememobno` bigint(10) NOT NULL,
  `comment` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sample`
--

INSERT INTO `sample` (`fname`, `firname`, `lname`, `date`, `role`, `male`, `Gender`, `address`, `emename`, `mobno`, `ememobno`, `comment`) VALUES
('krishna vasudev hari', 'krishna', ' vasudev', '2023-08-07 00:00:00.000000', 'Operator', '', 'Female', 'on the go lok he stay and fulfill is duties....', 'mahadeva', 8978654343, 7889878909, 'always be humble for everyone that i want to teach'),
('krishna vasudev hari', 'krishna', ' vasudev', '2023-08-07 00:00:00.000000', 'Operator', 'Male', 'Female', 'on the go lok he stay and fulfill is duties....', 'mahadeva', 8978654343, 7889878909, 'always be humble for everyone that i want to teach'),
('krishna vasudev hari', 'krishna', ' vasudev', '2023-08-07 00:00:00.000000', 'Operator', 'Male', 'Female', 'on the go lok he stay and fulfill is duties....', 'mahadeva', 8978654343, 7889878909, 'always be humble for everyone that i want to teach'),
('krishna vasudev hari', 'krishna', ' vasudev', '2023-08-07 00:00:00.000000', 'Operator', 'Male', '', 'on the go lok he stay and fulfill is duties....', 'mahadeva', 8978654343, 7889878909, 'always be humble for everyone that i want to teach');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
